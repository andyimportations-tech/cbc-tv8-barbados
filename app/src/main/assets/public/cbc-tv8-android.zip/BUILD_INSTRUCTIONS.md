# CBC TV 8 Barbados - Android APK Build Instructions

## Prerequisites
1. **Android Studio** - Download from https://developer.android.com/studio
2. **Java JDK 17** - Usually included with Android Studio

## Quick Build Steps

### Option 1: Build with Android Studio (Recommended)
1. Download the `cbc-tv8-android.zip` file
2. Extract the zip file
3. Open Android Studio
4. Select "Open an existing project"
5. Navigate to the extracted folder and select the `android` directory
6. Wait for Gradle sync to complete
7. Go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**
8. The APK will be generated at: `android/app/build/outputs/apk/debug/app-debug.apk`

### Option 2: Build from Command Line
```bash
# Navigate to the android directory
cd android

# Build debug APK
./gradlew assembleDebug

# Or build release APK (requires signing)
./gradlew assembleRelease
```

## Installing the APK

### On Android Device:
1. Transfer the APK to your device
2. Enable "Install from Unknown Sources" in Settings → Security
3. Open the APK file and tap "Install"

### Using ADB:
```bash
adb install app-debug.apk
```

## App Features
- **Live TV Stream**: Watch CBC TV 8 Barbados live
- **EPG Guide**: View today's programming schedule
- **HD Quality**: Up to 1080p video quality
- **Reminders**: Set reminders for upcoming programs
- **Fullscreen Mode**: Immersive viewing experience

## Package Details
- **App ID**: com.cbctv8.barbados
- **App Name**: CBC TV 8 Barbados
- **Min SDK**: 22 (Android 5.1)
- **Target SDK**: 34 (Android 14)

## Troubleshooting

### Build Fails with SDK Error
Make sure ANDROID_HOME environment variable is set:
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

### App Crashes on Launch
- Ensure internet connection is available
- Check if the device has WebView installed and updated

## Support
This app streams content from CBC TV 8 Barbados (https://www.cbc.bb/live)
