# CBC TV 8 Barbados - Android App

Live TV streaming app for CBC TV 8 Barbados.

## Features
- 📺 Live HD streaming (up to 1080p)
- 📅 Electronic Program Guide (EPG)
- 🔔 Program reminders
- 🌙 Dark theme optimized for viewing
- 📱 Works on phones and tablets

## Download APK

Go to the [Releases](../../releases) page to download the latest APK.

## Build Locally

### Prerequisites
- Android Studio or Android SDK
- JDK 17

### Build Steps
```bash
# Clone the repository
git clone <your-repo-url>
cd <repo-name>

# Build debug APK
./gradlew assembleDebug

# APK location
# app/build/outputs/apk/debug/app-debug.apk
```

## App Details
| Property | Value |
|----------|-------|
| Package | `com.cbctv8.barbados` |
| Min SDK | Android 5.1 (API 22) |
| Target SDK | Android 14 (API 34) |

## Stream Source
This app streams content from [CBC TV 8 Barbados](https://www.cbc.bb/live)

## License
This app is for personal use only. All broadcast content is property of Caribbean Broadcasting Corporation.
